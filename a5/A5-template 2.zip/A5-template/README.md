In this assignment, we basically created a spell disctionary and a spellchecker using HashSet.

Some questions I encountered while doing this assignment;
1. I tried to use StringBuilder for spliting method, but modifies it to substring() because my code with StringBuilder works for the last test (ab), not for the CurtCurie test.
2. I still cannot figure out why my transposition fails. I might be overly indulged into my logic so that I can't find the logic flaws.
3. For the SpellChecker, when I implement the output for *Words Read from a File*, the words are read, there is error detected, but there is no output. Does it imply that all of my methods cannot satisfy all condition? Or it is because I haven't fixed my transposition method?